import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const programs = [
    {
      title: 'ภาคปกติ',
      color: 'bg-blue-100',
      textColor: 'text-blue-700',
      description: [
        'เรียนในวันจันทร์ - ศุกร์ (เช้า-บ่าย)',
        'เหมาะสำหรับนักเรียนที่เพิ่งจบ ม.6 หรือเทียบเท่า',
        'ค่าเล่าเรียนตามอัตราอุดหนุนของภาครัฐ',
        'สามารถสมัครทุน กยศ./กรอ. ได้',
      ],
    },
    {
      title: 'ภาคพิเศษ',
      color: 'bg-yellow-100',
      textColor: 'text-yellow-700',
      description: [
        'เรียนวันเสาร์ - อาทิตย์ หรือภาคค่ำ',
        'เหมาะสำหรับผู้ทำงานประจำ หรือผู้มีเวลาจำกัด',
        'ค่าเล่าเรียนสูงกว่าภาคปกติ',
        'สามารถเรียนควบคู่กับงานประจำได้',
      ],
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-700 text-white py-10 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">มหาวิทยาลัยกาฬสินธุ์</h1>
          <p className="text-lg md:text-xl mb-6">แหล่งรวมความรู้เพื่ออนาคตของคุณ</p>
          <a
            href="#about"
            className="inline-block bg-white text-red-600 font-semibold px-6 py-3 rounded-full hover:bg-red-100 transition"
          >
            เทียบวิชาแต่ละสาขา
          </a>
        </div>
      </section>

      <section className="px-4 sm:px-6 mt-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-center text-red-600 mb-6">หลักสูตรภาคปกติและภาคพิเศษ</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {programs.map((program, idx) => (
            <div
              key={idx}
              className={`rounded-2xl shadow-md p-6 ${program.color} border-l-4 border-red-500`}
            >
              <h3 className={`text-xl sm:text-2xl font-semibold mb-4 ${program.textColor}`}>
                {program.title}
              </h3>
              <ul className="list-disc list-inside text-gray-700 space-y-2 text-sm sm:text-base">
                {program.description.map((desc, i) => (
                  <li key={i}>{desc}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Programs */}
      <section id="about" className="py-16 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-10 text-red-600">สาขา</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <Link
              to="/curriculumCE"
              className="block w-full bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition"
            >
              <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-2">วิศวคอมพิวเตอร์</h3>
              <p className="text-sm text-gray-600">วิศวกรรมศาสตรบัณฑิต</p>
            </Link>
            <Link
              to="/curriculumEN"
              className="block w-full bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition"
            >
              <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-2">วิศวกรรมไฟฟ้า</h3>
              <p className="text-sm text-gray-600">วิศวกรรมศาสตรบัณฑิต</p>
            </Link>
            <Link
              to="/curriculumMCE"
              className="block w-full bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition"
            >
              <h3 className="text-lg sm:text-xl font-semibold text-gray-800 mb-2">วิศวกรรมเมคคาทรอนิกส์</h3>
              <p className="text-sm text-gray-600">วิศวกรรมศาสตรบัณฑิต</p>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-4 sm:px-6 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-red-600">เกี่ยวกับเรา</h2>
          <p className="text-gray-700 leading-relaxed text-sm sm:text-base">
            มหาวิทยาลัยตัวอย่างมุ่งมั่นในการสร้างบุคลากรที่มีคุณภาพ มีคุณธรรม และสามารถปรับตัวในโลกอนาคต
            เรามีหลักสูตรหลากหลาย ทั้งวิทยาศาสตร์ วิศวกรรม ศิลปศาสตร์ และอื่นๆ
          </p>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
